(function(root){
 const normalize=s=>String(s||'').toLocaleLowerCase('kk').replace(/ә/g,'а').replace(/ғ/g,'г').replace(/қ/g,'к').replace(/ң/g,'н').replace(/ө/g,'о').replace(/[ұү]/g,'у').replace(/і/g,'и').replace(/ё/g,'е').replace(/[^\p{L}\p{N}/-]+/gu,' ').trim();
 const ignored=new Set(['кошеси','коше','кош','к','улица','ул','уй','дом','д','дангылы','проспект','пр','каласы']);
 const indexes=new WeakMap();
 function search(rows,city,query){
  const parts=normalize(query).split(' ').filter(x=>x&&!ignored.has(x));if(!parts.length)return [];
  const number=parts.find(x=>/^\d/.test(x));
  if(!indexes.has(rows))indexes.set(rows,rows.map(r=>({r,aliases:normalize([r.street,...(r.aliases||[]),r.house,r.city].join(' '))})));
  return indexes.get(rows).filter(x=>x.r.city===city).map(({r,aliases})=>{const match=parts.every(p=>/^\d/.test(p)?aliases.split(' ').includes(p):aliases.includes(p));return {r,score:match?(number?100:r.house?10:50):0};}).filter(x=>x.score).sort((a,b)=>b.score-a.score||a.r.street.localeCompare(b.r.street,'kk')||String(a.r.house).localeCompare(String(b.r.house),undefined,{numeric:true})).slice(0,30).map(x=>x.r);
 }
 root.AddressSearch={normalize,search};
})(globalThis);
