function showRuralMap(route){
 const modal=document.createElement('section');modal.className='map-modal';
 const top=document.createElement('div');top.className='map-top';const close=document.createElement('button');close.textContent='← Жабу';const title=document.createElement('strong');title.textContent=route.name;top.append(close,title);
 const canvas=document.createElement('div');canvas.style.cssText='flex:1;min-height:250px';modal.append(top,canvas);document.body.append(modal);
 const map=new maplibregl.Map({container:canvas,style:'https://tiles.openfreemap.org/styles/liberty',center:route.geometry.coordinates[0],zoom:10});
 map.on('load',()=>{map.addSource('road',{type:'geojson',data:{type:'Feature',properties:{},geometry:route.geometry}});map.addLayer({id:'road',type:'line',source:'road',paint:{'line-color':'#007dac','line-width':5}});const bounds=new maplibregl.LngLatBounds();route.geometry.coordinates.forEach(p=>bounds.extend(p));map.fitBounds(bounds,{padding:45});route.points?.forEach((p,i)=>new maplibregl.Marker({color:i?'#007dac':'#e6ae00'}).setLngLat([p.lon,p.lat]).addTo(map));});
 close.onclick=()=>{map.remove();modal.remove();};
}
