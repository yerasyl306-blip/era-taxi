window.DEFAULT_API_URL='';
window.serverReady=new Promise(resolve=>{
 if(!window.Android&&!location.hostname.endsWith('.chatgpt.site')&&!location.hostname.endsWith('.onrender.com')){resolve();return;}
 const script=document.createElement('script');script.src='https://yntaly-taxi.yerasyl306gmail-com.chatgpt.site/runtime-config.js?v='+Math.floor(Date.now()/60000);script.onload=script.onerror=()=>resolve();document.head.append(script);setTimeout(resolve,10000);
});
